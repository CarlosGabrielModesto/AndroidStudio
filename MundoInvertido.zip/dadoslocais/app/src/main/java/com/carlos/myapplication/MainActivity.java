package com.carlos.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    //variáveis que serao usadas para manipular os componentes do frontend.
    private Button btnSalvar;
    private TextInputEditText inputNome;
    private TextView txtUsuario;

    //constante que define o nome do arquivo xml
    private static final String ARQUIVO_XML = "NomeUsuario";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //grava nas variáveis o conteúdo dos componentes do frontend.
        btnSalvar= findViewById(R.id.btnSalvar);
        inputNome = findViewById(R.id.inputNome);
        txtUsuario= findViewById(R.id.txtUsuario);

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // cria o arquivo xml e define que somente o disposito pode gravar o conteudo.
                SharedPreferences preferences = getSharedPreferences(ARQUIVO_XML, 0);

                //cria um editor para o arquivo xml
                SharedPreferences.Editor editor = preferences.edit();

                //verifica se o usuario digitou algo
                if (inputNome.getText().toString().equals("")) {


                //envia uma mensagem pedindo pro usuario.
                Toast.makeText(getApplicationContext(), "Informe o seu nome..", Toast.LENGTH_SHORT).show();

            } else {


                // Variavel que recebera o nome do usuario.
                String nome = inputNome.getText().toString();

              //cria um par de chave/valor dentro do arquivo xml
                editor.putString("nome", nome,)  ;
                editor.commit();


                //apresenta o nome do usuario no text view
                txtUsuario.setText(nome);

            }
                 //define o arquivo xml que sera lido
                SharedPreferences preferencesRead = getSharedPreferences(ARQUIVO_XML, 0);

                if (preferencesRead.contains("nome")){

                    //Varíavel que armazana o nome do usuario ou um valor padrao.
                    String nome = preferences.getString("nome", "Usuário não definido");

                    //apresenta o nome do usuário no text view
                    txtUsuario.setText(nome);

                } else {
                    //apresenta um texto padrao caso nao exista nome gravado no arquivo xml. 
                    txtUsuario.setText("Usuário não definido");
                }





    });
    }
}